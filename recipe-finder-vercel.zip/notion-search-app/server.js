const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8000;
const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;

// Store the Notion token server-side
const NOTION_TOKEN = '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';

// Helper function to make fetch with retries
async function fetchWithRetry(url, options, retries = MAX_RETRIES) {
  for (let i = 0; i < retries; i++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      return response;
    } catch (error) {
      console.log(`Attempt ${i + 1} failed: ${error.message}`);
      if (i === retries - 1) throw error;
      await new Promise(resolve => setTimeout(resolve, RETRY_DELAY * (i + 1)));
    }
  }
}

const server = http.createServer(async (req, res) => {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  // Health check endpoint
  if (req.url === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', timestamp: Date.now() }));
    return;
  }

  // Check if token is configured
  if (req.url === '/api/check-token') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ hasToken: !!NOTION_TOKEN }));
    return;
  }

  // Proxy endpoint for Notion API - uses server-side token
  if (req.url === '/api/notion' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      try {
        const { endpoint, method, requestBody } = JSON.parse(body);
        
        // Use server-side token
        const token = NOTION_TOKEN;
        
        if (!token) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Server token not configured' }));
          return;
        }

        const notionUrl = `https://api.notion.com/v1${endpoint}`;
        const options = {
          method: method || 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Notion-Version': '2022-06-28',
            'Content-Type': 'application/json'
          }
        };

        if (requestBody && method !== 'GET') {
          options.body = JSON.stringify(requestBody);
        }

        console.log(`Notion API call: ${method} ${endpoint}`);
        
        const response = await fetchWithRetry(notionUrl, options);
        const data = await response.json();

        if (!response.ok) {
          console.log(`Notion API error: ${response.status} - ${JSON.stringify(data)}`);
        }

        res.writeHead(response.status, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(data));
      } catch (error) {
        console.error('Notion proxy error:', error.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: error.message, retry: true }));
      }
    });
    return;
  }

  // Serve static files
  if (req.url === '/' || req.url === '/index.html') {
    const filePath = path.join(__dirname, 'index.html');
    fs.readFile(filePath, (err, content) => {
      if (err) {
        res.writeHead(500);
        res.end('Error loading page');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(content);
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

// Keep server alive
server.keepAliveTimeout = 120000;
server.headersTimeout = 121000;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Notion token configured: ${!!NOTION_TOKEN}`);
});

// Handle uncaught errors
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
});

process.on('unhandledRejection', (error) => {
  console.error('Unhandled rejection:', error);
});
